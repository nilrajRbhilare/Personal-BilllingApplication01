## Packages
recharts | Dashboard analytics and revenue charts
date-fns | Date formatting and manipulation

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  mono: ["var(--font-mono)"],
}
